# P&PR - transformation logic and sample output

    pipeline/       the transformation, as it runs today
    sample/         the final table it produces
    source files/   the two source files that are not in Redshift

## What it produces

One table. Every run rebuilds it in full from the current sources.

    ppr_events    one row per metric event per scorecard column

That is the table the dashboard reads. Nothing else is needed to render it.

## Sources

Four come from the BI tables already in Redshift:

    bai_list_of_orders          the base, one row per order
    bai_tumor_documentation     one row per tissue procurement
    bai_infusion                one row per infused order
    veeva_komodo_atc_mapping    one row per treatment centre

Two do not. They are uploaded files, and they are in `source files/`:

    LTD_Reschedules             one row per change to a booked slot
    LTD_Cancellations           one row per cancelled slot

Those two carry one metric on their own, the count of procurement slots given
up with seven days notice or less. Without them the pipeline falls back to a
weaker proxy and records that it did so, rather than failing quietly.

## pipeline/

Five stages, run in order by `RUN_ALL.py`. The run stops at the first failure.

    build_analysis_table.py   reads the sources, builds one row per order,
                              derives the flags the metrics need
    build_cancellations.py    the seven day lost slot rule
    build_scorecard.py        the 13 metrics per centre per column
    build_datewindow.py       reshapes into the event-level table
    build_final_table.py      writes output/ppr_events.csv

    metrics.py                the 13 metric names, groups and event dates
    cancellations.py          the lost slot rule, shared by two stages
    baseline.py               freeze and diff, to confirm a change moved nothing

To run it:

    pip install -r requirements.txt
    # put the source files in data/
    python RUN_ALL.py

The final table lands at `output/ppr_events.csv`.

## Two checks run inside the pipeline

Stage 3 requires the period columns to add back to the launch-to-date column for
every centre and every additive metric.

Stage 4 re-aggregates the event table it just built and compares every cell
against the scorecard computed separately in stage 3.

Either failing stops the run before an output is written.

## Two things about the final table

It has no unique key and should not have one. Each event is written once per
scorecard column it belongs to, so identical looking rows are real. Do not
deduplicate it.

Rows with a blank `event_date` are real events that have no date. They belong in
the table; dropping them makes every period column look better than it was.

## sample/

`ppr_events.csv`, complete, in the column order the reporting table uses. Read
`sample/README.md` first: the copy here was produced from test data.
